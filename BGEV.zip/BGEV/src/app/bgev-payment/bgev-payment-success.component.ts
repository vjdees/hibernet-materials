import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
    selector: 'bgev-payment-success',
    templateUrl: './bgev-payment-success.component.html',
    styleUrls: ['./bgev-payment-success.component.scss']
})

export class BgEvPaymentSuccessComponent {
    
}